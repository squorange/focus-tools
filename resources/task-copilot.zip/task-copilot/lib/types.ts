// Task structure types

export interface Substep {
  id: string;
  text: string;
}

export interface Step {
  id: string;
  text: string;
  substeps: Substep[];
}

export interface TaskBreakdown {
  taskTitle: string;
  steps: Step[];
  message: string;
}

// Conversation types

export interface Message {
  role: "user" | "assistant";
  content: string;
}

export interface ConversationState {
  originalIntent: string;
  currentBreakdown: TaskBreakdown | null;
  messages: Message[];
  isFinalized: boolean;
}

// API types

export interface StructureRequest {
  intent: string;
  conversationHistory: Message[];
}

export interface StructureResponse {
  breakdown: TaskBreakdown;
  error?: string;
}
