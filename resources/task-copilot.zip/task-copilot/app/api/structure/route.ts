import { NextRequest, NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { SYSTEM_PROMPT } from "@/lib/prompts";
import { Message, TaskBreakdown } from "@/lib/types";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

export async function POST(request: NextRequest) {
  try {
    const { intent, conversationHistory } = await request.json();

    // Build messages array
    const messages: { role: "user" | "assistant"; content: string }[] = [];

    if (conversationHistory && conversationHistory.length > 0) {
      // Include existing conversation
      messages.push(...conversationHistory);
    } else {
      // First message - just the intent
      messages.push({ role: "user", content: intent });
    }

    // Call Claude API
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: messages,
    });

    // Extract text content
    const textContent = response.content.find((block) => block.type === "text");
    if (!textContent || textContent.type !== "text") {
      throw new Error("No text response from Claude");
    }

    // Parse JSON response
    const breakdown: TaskBreakdown = JSON.parse(textContent.text);

    return NextResponse.json({ breakdown });
  } catch (error) {
    console.error("Error in structure API:", error);

    // Handle JSON parse errors specifically
    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { error: "Failed to parse AI response as JSON" },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { error: "Failed to structure task" },
      { status: 500 }
    );
  }
}
