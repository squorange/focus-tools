"use client";

import { useState } from "react";
import { ConversationState, TaskBreakdown, Message } from "@/lib/types";

// Initial state
const initialState: ConversationState = {
  originalIntent: "",
  currentBreakdown: null,
  messages: [],
  isFinalized: false,
};

export default function Home() {
  const [state, setState] = useState<ConversationState>(initialState);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Phase: "intent" (initial input) or "refine" (conversation)
  const phase = state.currentBreakdown ? "refine" : "intent";

  // Handle initial intent submission
  async function handleIntentSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/structure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          intent: inputValue,
          conversationHistory: [],
        }),
      });

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      // Update state with initial breakdown
      setState({
        originalIntent: inputValue,
        currentBreakdown: data.breakdown,
        messages: [
          { role: "user", content: inputValue },
          { role: "assistant", content: JSON.stringify(data.breakdown) },
        ],
        isFinalized: false,
      });

      setInputValue("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  }

  // Handle refinement submission
  async function handleRefinementSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    setIsLoading(true);
    setError(null);

    // Add user message to history
    const newMessages: Message[] = [
      ...state.messages,
      { role: "user", content: inputValue },
    ];

    try {
      const response = await fetch("/api/structure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          intent: state.originalIntent,
          conversationHistory: newMessages,
        }),
      });

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      // Check if finalized
      const isFinalized =
        inputValue.toLowerCase().includes("looks good") ||
        inputValue.toLowerCase().includes("done") ||
        inputValue.toLowerCase().includes("finalize");

      // Update state with new breakdown
      setState({
        ...state,
        currentBreakdown: data.breakdown,
        messages: [
          ...newMessages,
          { role: "assistant", content: JSON.stringify(data.breakdown) },
        ],
        isFinalized,
      });

      setInputValue("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  }

  // Reset to start over
  function handleReset() {
    setState(initialState);
    setInputValue("");
    setError(null);
  }

  return (
    <main className="min-h-screen p-8 max-w-2xl mx-auto">
      <header className="mb-8">
        <h1 className="text-2xl font-semibold text-neutral-800 dark:text-neutral-100">
          Task Co-Pilot
        </h1>
        <p className="text-neutral-600 dark:text-neutral-400 mt-1">
          Turn rough ideas into actionable steps
        </p>
      </header>

      {/* Error display */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-300">
          {error}
        </div>
      )}

      {/* Intent Phase */}
      {phase === "intent" && (
        <section>
          <form onSubmit={handleIntentSubmit}>
            <label
              htmlFor="intent"
              className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2"
            >
              What do you want to accomplish?
            </label>
            <textarea
              id="intent"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="I need to do taxes somehow..."
              className="w-full p-4 border border-neutral-300 dark:border-neutral-700 rounded-lg 
                         bg-white dark:bg-neutral-800 text-neutral-800 dark:text-neutral-100
                         placeholder-neutral-400 dark:placeholder-neutral-500
                         focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent
                         resize-none"
              rows={3}
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !inputValue.trim()}
              className="mt-4 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-neutral-400
                         text-white font-medium rounded-lg transition-colors
                         focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              {isLoading ? "Thinking..." : "Break it down"}
            </button>
          </form>
        </section>
      )}

      {/* Refinement Phase */}
      {phase === "refine" && state.currentBreakdown && (
        <section className="space-y-6">
          {/* Task Breakdown Display */}
          <div className="p-6 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg">
            <h2 className="text-lg font-semibold text-neutral-800 dark:text-neutral-100 mb-4">
              {state.currentBreakdown.taskTitle}
            </h2>

            <ol className="space-y-3">
              {state.currentBreakdown.steps.map((step) => (
                <li key={step.id}>
                  <div className="flex gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-neutral-100 dark:bg-neutral-700 rounded-full 
                                     flex items-center justify-center text-sm font-medium text-neutral-600 dark:text-neutral-300">
                      {step.id}
                    </span>
                    <span className="text-neutral-700 dark:text-neutral-200">
                      {step.text}
                    </span>
                  </div>

                  {/* Substeps */}
                  {step.substeps.length > 0 && (
                    <ol className="mt-2 ml-9 space-y-2">
                      {step.substeps.map((substep) => (
                        <li
                          key={substep.id}
                          className="flex gap-2 text-sm text-neutral-600 dark:text-neutral-400"
                        >
                          <span className="text-neutral-400 dark:text-neutral-500">
                            {substep.id}.
                          </span>
                          <span>{substep.text}</span>
                        </li>
                      ))}
                    </ol>
                  )}
                </li>
              ))}
            </ol>
          </div>

          {/* AI Message */}
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
            <p className="text-blue-800 dark:text-blue-200">
              {state.currentBreakdown.message}
            </p>
          </div>

          {/* Refinement Input */}
          {!state.isFinalized && (
            <form onSubmit={handleRefinementSubmit}>
              <label
                htmlFor="refinement"
                className="block text-sm font-medium text-neutral-700 dark:text-neutral-300 mb-2"
              >
                Refine the breakdown
              </label>
              <div className="flex gap-3">
                <input
                  id="refinement"
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Step 3 is too vague..."
                  className="flex-1 p-3 border border-neutral-300 dark:border-neutral-700 rounded-lg
                             bg-white dark:bg-neutral-800 text-neutral-800 dark:text-neutral-100
                             placeholder-neutral-400 dark:placeholder-neutral-500
                             focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  disabled={isLoading}
                />
                <button
                  type="submit"
                  disabled={isLoading || !inputValue.trim()}
                  className="px-5 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-neutral-400
                             text-white font-medium rounded-lg transition-colors
                             focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                >
                  {isLoading ? "..." : "Send"}
                </button>
              </div>
              <p className="mt-2 text-sm text-neutral-500 dark:text-neutral-400">
                Say "looks good" when you're satisfied
              </p>
            </form>
          )}

          {/* Finalized State */}
          {state.isFinalized && (
            <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
              <p className="text-green-800 dark:text-green-200 font-medium">
                ✓ Breakdown finalized
              </p>
            </div>
          )}

          {/* Reset Button */}
          <button
            onClick={handleReset}
            className="text-sm text-neutral-500 hover:text-neutral-700 dark:text-neutral-400 dark:hover:text-neutral-200
                       underline underline-offset-2"
          >
            Start over with a new task
          </button>
        </section>
      )}
    </main>
  );
}
