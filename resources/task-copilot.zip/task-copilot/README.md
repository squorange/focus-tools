# Task Co-Pilot

AI-powered task breakdown assistant — a POC for the Focus Tools planning loop.

## Purpose

Learn Claude API patterns with minimal complexity:
- Multi-turn conversation management
- Structured JSON output parsing
- Prompt design for task structuring
- Conversational refinement UX

## Quick Start

```bash
# Install dependencies
npm install

# Set up environment
cp .env.example .env.local
# Edit .env.local and add your Anthropic API key

# Run development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Project Structure

```
task-copilot/
├── app/
│   ├── api/
│   │   └── structure/
│   │       └── route.ts    # Claude API endpoint
│   ├── globals.css         # Tailwind styles
│   ├── layout.tsx          # Root layout
│   └── page.tsx            # Main UI
├── lib/
│   ├── prompts.ts          # System prompt
│   └── types.ts            # TypeScript types
├── .env.example            # Environment template
└── README.md
```

## How It Works

1. **User enters rough intent** → "I need to do taxes somehow"
2. **Claude structures into steps** → Returns JSON with title, steps, message
3. **User requests refinements** → "Step 3 is too vague"
4. **Claude adjusts breakdown** → Updated JSON preserving context
5. **User finalizes** → "Looks good"

## Interaction Flow

```
[Intent Input] → [AI Breakdown] → [Refinement Loop] → [Finalized Task]
```

## Learning Goals Checklist

- [ ] Claude API integration working
- [ ] System prompt produces consistent output
- [ ] JSON parsing handles edge cases
- [ ] Conversation context maintained across turns
- [ ] Refinement requests handled correctly
- [ ] Error states handled gracefully
- [ ] UI feels responsive during API calls

## Learnings Log

Document discoveries and patterns here as you build:

### Prompt Design
- _What worked / didn't work for task structuring?_
- _How to handle ambiguous refinement requests?_

### API Patterns
- _Token usage observations_
- _Response time considerations_
- _Error handling edge cases_

### State Management
- _Conversation history patterns_
- _When to reset vs. continue context_

### UX Insights
- _Loading state feedback_
- _What makes refinement feel natural?_

---

## Related Docs

- [Focus Tools Product Doc](/docs/focus-tools-product-doc.md)
- [Anthropic API Docs](https://docs.anthropic.com/)
